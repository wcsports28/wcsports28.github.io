# Upload to GitHub — no commands needed (about 5 minutes)

## 1. Create the repo
github.com → **+** (top right) → **New repository** → name it `wcs-nhl-line-zone` → **Public** → **Create repository**.

## 2. Upload the files
On the new repo page click **uploading an existing file**. Drag in everything from this folder:
`build_zone.py`, `wcs_goalie_update.py`, `template.html`, `WCS_NHL_Line_Stats.xlsx`, `README.md`, `line-zone-workflow.yml`, and the **docs** folder.
Click **Commit changes**.

## 3. Add the daily schedule
Your computer hides the `.github` folder, so add it by hand:
**Add file → Create new file** → in the name box type exactly
`.github/workflows/line-zone.yml`
→ open `line-zone-workflow.yml` from this folder, copy everything, paste it in → **Commit changes**.

## 4. Allow the build to save updates
**Settings → Actions → General → Workflow permissions → Read and write permissions → Save.**

## 5. Turn on the website
**Settings → Pages →** Source: **Deploy from a branch** → Branch **main**, folder **/docs** → **Save**.

## 6. Run the first build
**Actions** tab → **WCS NHL Line Zone — daily build** → **Run workflow** → **Run workflow**.
Wait for the green check (2–4 minutes).

## 7. Open your page
`https://YOUR-USERNAME.github.io/wcs-nhl-line-zone/` — bookmark it. It updates itself every day at
3:45, 5:15 and 6:30 PM ET, October through June.

**Change the design later:** edit `template.html` (pencil icon on GitHub), commit, then Run workflow.
**A build failed?** Open the red run in the Actions tab, copy the error, and send it to Claude.
**Private page:** GitHub Pages needs a paid plan for private repos.
